package com.cucumberPJT.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.cucumberPJT.BaseClass;

public class HomePage extends BaseClass {
	WebDriver driver;
	public HomePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//a[text()='Mobiles']")
	public WebElement mobiles;
	
	@FindBy(xpath="//span[text()='Hello, sign in']")
	public WebElement signInBtn;

}
