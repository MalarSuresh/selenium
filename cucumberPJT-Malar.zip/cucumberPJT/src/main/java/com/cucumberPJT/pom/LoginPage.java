package com.cucumberPJT.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.cucumberPJT.BaseClass;

public class LoginPage extends BaseClass {
	WebDriver driver1;
	public LoginPage(WebDriver Driver) {
		driver1=Driver;
		PageFactory.initElements(driver1, this);
	}
	
	
	@FindBy(xpath="//label[@class='a-form-label']")
	public WebElement checkLoginPage;
	
	@FindBy(id="ap_email")
	public WebElement email;
	
	@FindBy(id="continue")
	public WebElement continueBtn;

	@FindBy(id="signInSubmit")
	public WebElement signInBtn;

	@FindBy(id="ap_password")
	public WebElement password;

}
