package com.cucumberPJT.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.cucumberPJT.BaseClass;

public class ProductPage extends BaseClass {
	WebDriver driver1;
	public ProductPage(WebDriver driver) {
		driver1=driver;
		PageFactory.initElements(driver1, this);
		System.out.println("Hello");
	}

	@FindBy(xpath="//span[text()='Hello, Malar']")
	public WebElement profileName;

	@FindBy(id="twotabsearchtextbox")
	public WebElement searchBox;
	
	@FindBy(id="nav-search-submit-button")
	public WebElement searchBtn;
	
	@FindBy(xpath="(//span[text()='All'])[2]")
	public WebElement all;
}
